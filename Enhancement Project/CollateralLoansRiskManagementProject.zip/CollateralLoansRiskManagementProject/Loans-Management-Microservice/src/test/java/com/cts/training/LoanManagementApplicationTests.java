package com.cts.training;

import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * @Test LoanManagementServiceImpl Class
 * @author POD-6
 */
@SpringBootTest
public class LoanManagementApplicationTests {

	@Test
	public void contextLoads() {
		assertTrue(true);
	}

}
