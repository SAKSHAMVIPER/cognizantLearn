package com.cts.project;

import static org.junit.Assert.*;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * Test - RiskAssessmentServiceApplication class
 */
@SpringBootTest
public class RiskAssessmentServiceApplicationTests {
    @Test
    public void testApplication(){
        assertTrue(true);
    }
}
